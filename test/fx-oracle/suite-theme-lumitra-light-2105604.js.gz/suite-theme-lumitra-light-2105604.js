/* <lumitra-light>: the Lumitra brand image, a ring of fine light particles with a glow pass.
   Canonical copy: knowledge-base/brand/lumitra-mint/lumitra-light.js (plan 2026-11-22-lumitra-rebrand-mint-light).
   Usage:  <script src="lumitra-light.js" type="module"></script>
           <lumitra-light style="height:520px"></lumitra-light>
   Attributes: bg (default #04090b), glow (0 to 2, default 1), density (0.25 to 1, default 1).
   Honors prefers-reduced-motion (draws one still frame), pauses off screen, leans toward the pointer.
   Colour mix is the decided 60/30/10: mint leads, light blue rims, indigo only inside the glow. */
const STOPS = [
  [0.0, [82, 255, 165]], [0.3, [82, 255, 165]], [0.5, [59, 132, 255]], [0.62, [88, 46, 255]],
  [0.72, [59, 132, 255]], [0.88, [82, 255, 165]], [1.0, [82, 255, 165]],
];
const f3 = (v) => (v / 255).toFixed(3);
const PAL = (() => {
  let s = 'vec3 pal(float x){';
  for (let i = 1; i < STOPS.length; i++) {
    const [a, ca] = STOPS[i - 1], [b, cb] = STOPS[i];
    s += `if(x<=${b.toFixed(3)}){return mix(vec3(${f3(ca[0])},${f3(ca[1])},${f3(ca[2])}),vec3(${f3(cb[0])},${f3(cb[1])},${f3(cb[2])}),(x-${a.toFixed(3)})/${Math.max(0.001, b - a).toFixed(3)});}`;
  }
  return s + 'return vec3(0.32,1.0,0.65);}';
})();

const VS = `#version 300 es
in vec3 a;
uniform float t; uniform vec2 res; uniform vec2 ptr; uniform float R; uniform float W; uniform float dpr; uniform float glow;
out float vT; out float vA;
void main(){
 float th=a.x, u=a.y, rnd=a.z;
 float band=W*(0.65+0.35*sin(3.0*th+t*0.35)+0.15*sin(7.0*th-t*0.5));
 float w1=sin(6.0*th+u*2.2+t*0.55)*0.55+sin(13.0*th-u*3.1-t*0.8)*0.28+sin(23.0*th+u*5.0+t*1.1)*0.12;
 float w2=sin(4.0*th-u*1.7-t*0.4+sin(2.0*th+t*0.2))*0.6;
 float r=R+(u-0.5)*band+W*0.55*w1*(0.4+u)+W*0.25*w2;
 float z=sin(th*2.0+t*0.3+u)*0.18+(u-0.5)*0.3;
 vec2 p=vec2(cos(th),sin(th))*r;
 p.x+=ptr.x*W*0.6*(1.0-z); p.y+=ptr.y*W*0.6*(1.0-z);
 gl_Position=vec4(p.x/res.x*2.0, p.y/res.y*2.0, 0.0, 1.0);
 float base=(1.0+0.9*rnd*rnd)*(1.0+z*0.6);
 gl_PointSize=glow>0.5 ? base*dpr*16.0 : base*dpr;
 vT=fract(th/6.2831853+0.125);
 float edge=1.0-abs(u-0.5)*1.6;
 float al=(0.30+0.45*rnd)*(0.45+0.55*edge)*(0.75+0.25*sin(t*2.0+rnd*40.0));
 vA=glow>0.5 ? al*0.028 : al;
}`;
const FS = `#version 300 es
precision highp float; in float vT; in float vA; uniform float glow; out vec4 o;
${PAL}
void main(){
 vec2 c=gl_PointCoord-0.5; float d=dot(c,c); if(d>0.25) discard;
 if(glow>0.5){
  float f=smoothstep(0.25,0.0,d); f*=f;
  vec3 col=mix(pal(vT), vec3(0.345,0.18,1.0), 0.55);   // indigo lives only inside the glow
  o=vec4(col*vA*f,1.0); return;
 }
 float f=smoothstep(0.25,0.0,d);
 o=vec4(pal(vT)*vA*f+vec3(0.08)*vA*f*f,1.0);
}`;

function compile(gl, type, src) {
  const s = gl.createShader(type);
  gl.shaderSource(s, src); gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) || 'shader failed');
  return s;
}

class LumitraLight extends HTMLElement {
  connectedCallback() {
    if (this._started) return;
    this._started = true;
    const root = this.attachShadow({ mode: 'open' });
    root.innerHTML = '<style>:host{display:block;position:relative;min-height:240px;overflow:hidden}canvas{position:absolute;inset:0;width:100%;height:100%;display:block}</style><canvas aria-hidden="true"></canvas>';
    const cv = root.querySelector('canvas');
    const bgHex = (this.getAttribute('bg') || '#04090b').replace('#', '');
    const bg = [0, 2, 4].map((i) => parseInt(bgHex.slice(i, i + 2), 16) / 255);
    const glowAmt = Math.max(0, Math.min(2, parseFloat(this.getAttribute('glow') ?? '1')));
    const density = Math.max(0.25, Math.min(1, parseFloat(this.getAttribute('density') ?? '1')));
    const gl = cv.getContext('webgl2', { premultipliedAlpha: false, antialias: true });
    if (!gl) { this.style.background = 'radial-gradient(50% 50% at 50% 50%, rgb(82 255 165 / .12), rgb(88 46 255 / .10) 55%, transparent 75%)'; return; }
    let pr;
    try {
      pr = gl.createProgram();
      gl.attachShader(pr, compile(gl, gl.VERTEX_SHADER, VS));
      gl.attachShader(pr, compile(gl, gl.FRAGMENT_SHADER, FS));
      gl.linkProgram(pr);
      if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(pr));
    } catch (e) { console.error('lumitra-light:', e); return; }
    const K = 120, N = Math.round(760 * density), count = K * N, data = new Float32Array(count * 3);
    let i = 0;
    for (let k = 0; k < K; k++) { const ph = Math.random() * 0.01; for (let n = 0; n < N; n++) { data[i++] = (n / N) * 6.2831853 + ph; data[i++] = k / (K - 1); data[i++] = Math.random(); } }
    const vao = gl.createVertexArray(); gl.bindVertexArray(vao);
    gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer()); gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(pr, 'a'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 3, gl.FLOAT, false, 0, 0);
    const U = (n) => gl.getUniformLocation(pr, n);
    const uT = U('t'), uRes = U('res'), uP = U('ptr'), uR = U('R'), uW = U('W'), uDpr = U('dpr'), uGlow = U('glow');
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    let W = 1, H = 1, dpr = 1, mx = 0, my = 0, tx = 0, ty = 0, visible = true, raf = 0;
    const t0 = performance.now();
    const resize = () => { dpr = Math.min(2, devicePixelRatio || 1); W = this.clientWidth || 1; H = this.clientHeight || 1; cv.width = W * dpr; cv.height = H * dpr; };
    this._ro = new ResizeObserver(() => { resize(); if (reduce) frame(performance.now()); });
    this._ro.observe(this);
    resize();
    this.addEventListener('pointermove', (e) => { const b = this.getBoundingClientRect(); tx = (e.clientX - b.left) / b.width - 0.5; ty = -((e.clientY - b.top) / b.height - 0.5); });
    this.addEventListener('pointerleave', () => { tx = 0; ty = 0; });
    const frame = (now) => {
      raf = 0;
      const t = (now - t0) / 1000 + 7;
      mx += (tx - mx) * 0.05; my += (ty - my) * 0.05;
      gl.viewport(0, 0, cv.width, cv.height);
      gl.clearColor(bg[0], bg[1], bg[2], 1); gl.clear(gl.COLOR_BUFFER_BIT);
      gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE);
      gl.useProgram(pr); gl.bindVertexArray(vao);
      const R = Math.min(W * 0.37, H * 0.47);
      gl.uniform1f(uT, t); gl.uniform2f(uRes, W, H); gl.uniform2f(uP, mx, my); gl.uniform1f(uR, R); gl.uniform1f(uW, R * 0.2); gl.uniform1f(uDpr, dpr);
      if (glowAmt > 0) { gl.uniform1f(uGlow, 1); for (let g = 0; g < glowAmt; g += 1) gl.drawArrays(gl.POINTS, 0, count); }
      gl.uniform1f(uGlow, 0); gl.drawArrays(gl.POINTS, 0, count);
      if (visible && !reduce) raf = requestAnimationFrame(frame);
    };
    this._io = new IntersectionObserver((es) => { visible = es[0].isIntersecting; if (visible && !raf) raf = requestAnimationFrame(frame); });
    this._io.observe(this);
    raf = requestAnimationFrame(frame);
    this._stop = () => { if (raf) cancelAnimationFrame(raf); raf = 0; };
  }
  disconnectedCallback() { this._stop?.(); this._ro?.disconnect(); this._io?.disconnect(); this._started = false; }
}
if (!customElements.get('lumitra-light')) customElements.define('lumitra-light', LumitraLight);
export { LumitraLight };
