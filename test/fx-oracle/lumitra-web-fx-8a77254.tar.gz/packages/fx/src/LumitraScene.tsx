"use client";

/**
 * <LumitraScene config={SceneConfig} />
 *
 * The engine entry point. Owns a single r3f Canvas, a single EffectComposer,
 * and a small object registry so post layers can bind to content meshes by id.
 *
 * Pipeline:
 *   content layers (back -> front, rendered as meshes)
 *   post layers    (top of the layer list to bottom = composer pass order)
 *
 * The leva editor is mounted only when `editor` is true or the URL carries
 * `?tune=1`. The panel is auto-generated from each layer's param schema and
 * writes back into the same `config` object the engine renders from. That
 * single-source-of-truth (panel <-> scene config) is the seam Phase 1's JSON
 * export/import builds on. Phase 3 adds a sibling DOM `LayerListPanel` that
 * mutates `config.layers` (add / remove / reorder / toggle) through the same
 * setConfig channel; both panels stay in lockstep because they share the
 * state.
 *
 * Phase 3 also wires a drei `PerformanceMonitor` inside the Canvas. When the
 * measured fps stays below the spec section 8 floor (60 desktop, 30 mobile),
 * the monitor flips a `perfLow` flag we route two ways:
 *   - dpr is clamped to [1, 1] (drop the pixel budget by up to 3x)
 *   - layers marked `heavy` in the registry are dropped from the pipeline
 * The downshift is sticky for the lifetime of the canvas; we don't try to
 * upshift on a brief recovery because that produces a visible jank cycle.
 *
 * WebGL guard (spec section 8): a context can be impossible to create on a
 * locked-down/old browser or, in dev, a crashed/wedged GPU process. We
 * pre-flight `detectWebGL` and render `fallback` instead of mounting the
 * Canvas if it fails, so the page degrades to a static frame rather than
 * throwing an unhandled rejection / error overlay. A `WebGLErrorBoundary` and
 * a `webglcontextlost` listener cover the cases where the context dies after
 * the probe passed (e.g. the GPU process crashes mid-session).
 */

import { Canvas } from "@react-three/fiber";
import { EffectComposer } from "@react-three/postprocessing";
import { PerformanceMonitor } from "@react-three/drei";
import { Leva } from "leva";
import {
  Component,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { Object3D } from "three";

import { getLayerDefinition } from "./registry";
import type {
  InteractivitySpec,
  Layer,
  LayerContext,
  ParamSchema,
  ParamValues,
  ParamsSchema,
  SceneConfig,
} from "./types";
import { LevaEditor } from "./editor/LevaEditor";
import { EditorTools } from "./editor/EditorTools";
import { LayerListPanel } from "./editor/LayerListPanel";
import { instantiateLayer } from "./editor/layerOps";
import {
  clearPersistedScene,
  loadPersistedScene,
  persistScene,
} from "./editor/persistence";

// Side effect: register all built-in layers on first import of the scene.
import "./builtins";

interface LumitraSceneProps {
  config: SceneConfig;
  className?: string;
  /** Force the live editor on/off; default reads `?tune=1` from the URL. */
  editor?: boolean;
  /**
   * Rendered in place of the Canvas when WebGL is unavailable (locked-down or
   * old browsers, or a crashed/wedged GPU process). The scene background is
   * always painted underneath, so the hero never flashes a transparent box.
   * When omitted, the fallback is just that background frame.
   */
  fallback?: ReactNode;
}

function extractValues<P extends ParamsSchema>(params: P): ParamValues<P> {
  const out = {} as Record<string, ParamSchema["value"]>;
  for (const [k, schema] of Object.entries(params)) {
    out[k] = schema.value;
  }
  return out as ParamValues<P>;
}

function readPrefersReducedMotion(): boolean {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function readTuneFlag(): boolean {
  if (typeof window === "undefined") return false;
  return new URLSearchParams(window.location.search).has("tune");
}

/**
 * Coarse-pointer (touch) heuristic. We don't ship Fluid on phones, and we
 * pre-clamp the dpr cap there even before PerformanceMonitor fires. Same
 * predicate Tailwind / drei use; safe in SSR (returns false).
 */
function isMobileLikely(): boolean {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(hover: none) and (pointer: coarse)").matches;
}

/**
 * One-shot WebGL capability probe. Returns false when no context can be
 * created (GPU disabled/crashed, software rendering off, ancient browser). We
 * create a throwaway context and immediately release it so the probe itself
 * doesn't hold a slot against the browser's WebGL context cap.
 */
function detectWebGL(): boolean {
  if (typeof window === "undefined") return false;
  try {
    const canvas = document.createElement("canvas");
    const gl = (canvas.getContext("webgl2") ||
      canvas.getContext("webgl")) as WebGLRenderingContext | null;
    if (!gl) return false;
    gl.getExtension("WEBGL_lose_context")?.loseContext();
    return true;
  } catch {
    return false;
  }
}

/**
 * Backstop for the synchronous throw r3f raises when WebGLRenderer
 * construction fails (probe passed but creation still failed). Renders nothing
 * on failure and notifies the parent, which swaps in the fallback.
 */
class WebGLErrorBoundary extends Component<
  { onError: () => void; children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch() {
    this.props.onError();
  }
  render() {
    return this.state.failed ? null : this.props.children;
  }
}

export function LumitraScene({ config: initialConfig, className, editor, fallback }: LumitraSceneProps) {
  // The engine owns `config` after mount so the editor can mutate it; the
  // `config` prop is a seed value only. If the parent needs to swap scenes,
  // it should remount LumitraScene with a fresh React key.
  //
  // The lazy initializer runs once on mount (client-only, since LumitraScene
  // boots through `dynamic(ssr:false)`). We only rehydrate the localStorage
  // autosave when the editor is active: a plain production page must always
  // render the canonical `config` it was handed, never a tuning blob. The
  // autosave is a tuning convenience, and an older blob can be stale against
  // the current layer schemas; trusting it on every page load is what let a
  // single bad tuning session poison the live hero. No hydration mismatch
  // because there's no SSR for this component.
  const [config, setConfig] = useState<SceneConfig>(() => {
    const tuning = editor ?? readTuneFlag();
    return (tuning ? loadPersistedScene(initialConfig.id) : null) ?? initialConfig;
  });

  const [objects, setObjects] = useState<Record<string, Object3D>>({});
  const reduce = useMemo(() => readPrefersReducedMotion(), []);
  const showEditor = editor ?? readTuneFlag();

  // WebGL capability gate. If the GPU can't hand us a context (crashed/wedged
  // process, locked-down browser), render `fallback` instead of mounting the
  // Canvas so the page degrades gracefully instead of throwing.
  const [webglOk, setWebglOk] = useState<boolean>(() => detectWebGL());

  // Performance downshift state (sticky). Initialized true on mobile-class
  // pointers so we don't pay the "decline -> downshift" cost on devices that
  // were never going to clear the 60fps bar anyway.
  const [perfLow, setPerfLow] = useState<boolean>(() => isMobileLikely());

  // Debounced autosave. Only persists while the editor is open so a static
  // hero page never writes to localStorage. The first commit is delayed by
  // 400 ms so a tuning storm (slider drag) hits storage a single time.
  const persistTimer = useRef<number | null>(null);
  useEffect(() => {
    if (!showEditor) return;
    if (persistTimer.current != null) {
      window.clearTimeout(persistTimer.current);
    }
    persistTimer.current = window.setTimeout(() => {
      persistScene(config);
      persistTimer.current = null;
    }, 400);
    return () => {
      if (persistTimer.current != null) {
        window.clearTimeout(persistTimer.current);
        persistTimer.current = null;
      }
    };
  }, [config, showEditor]);

  // Bump this on every wholesale replacement (Import / Reset / preset load /
  // layer list mutation) so the leva panel remounts against the new layer
  // set. Without the key bump, leva keeps its internal store keyed by
  // folder/label and quietly diverges from a freshly-imported config.
  const [editorRev, setEditorRev] = useState(0);

  const replaceConfig = useCallback((next: SceneConfig) => {
    setConfig(next);
    setEditorRev((r) => r + 1);
  }, []);

  const resetConfig = useCallback(() => {
    clearPersistedScene(initialConfig.id);
    setConfig(initialConfig);
    setEditorRev((r) => r + 1);
  }, [initialConfig]);

  /** Replace the layers array, keep everything else; bump leva rev. */
  const replaceLayers = useCallback((next: Layer[]) => {
    setConfig((prev) => ({ ...prev, layers: next }));
    setEditorRev((r) => r + 1);
  }, []);

  /** Mint and append a new layer of `type` to the end of the stack. */
  const addLayer = useCallback((type: string) => {
    setConfig((prev) => {
      const layer = instantiateLayer(type, prev.layers);
      if (!layer) return prev;
      return { ...prev, layers: [...prev.layers, layer] };
    });
    setEditorRev((r) => r + 1);
  }, []);

  const registerObject = useCallback((id: string, obj: Object3D | null) => {
    setObjects((prev) => {
      if (obj === null) {
        if (!(id in prev)) return prev;
        const next = { ...prev };
        delete next[id];
        return next;
      }
      if (prev[id] === obj) return prev;
      return { ...prev, [id]: obj };
    });
  }, []);

  const ctx: LayerContext = useMemo(
    () => ({
      registerObject,
      getObject: (id: string) => objects[id] ?? null,
      reduce,
    }),
    [registerObject, objects, reduce],
  );

  const updateLayerParams = useCallback(
    (layerId: string, partial: Record<string, ParamSchema["value"]>) => {
      setConfig((prev) => ({
        ...prev,
        layers: prev.layers.map((layer) => {
          if (layer.id !== layerId) return layer;
          const next: Record<string, ParamSchema> = {};
          for (const [k, s] of Object.entries(layer.params)) {
            if (k in partial) {
              // Preserve schema metadata (min/max/options); replace only `value`.
              next[k] = { ...s, value: partial[k] } as ParamSchema;
            } else {
              next[k] = s;
            }
          }
          return { ...layer, params: next };
        }),
      }));
    },
    [],
  );

  const updateLayerInteractivity = useCallback(
    (layerId: string, next: InteractivitySpec | undefined) => {
      setConfig((prev) => ({
        ...prev,
        layers: prev.layers.map((layer) =>
          layer.id !== layerId ? layer : { ...layer, interactivity: next },
        ),
      }));
    },
    [],
  );

  // Apply the perf downshift: drop heavy layers and clamp dpr to 1. Layers
  // are filtered before kind splitting so the visibility / kind logic stays
  // ignorant of perf state.
  const liveLayers = useMemo(() => {
    if (!perfLow) return config.layers;
    return config.layers.filter((l) => !getLayerDefinition(l.type)?.heavy);
  }, [config.layers, perfLow]);

  const dprClamp = perfLow ? ([1, 1] as [number, number]) : config.dpr;

  const visibleLayers = liveLayers.filter((l) => l.visible);
  const contentLayers = visibleLayers.filter(
    (l) => getLayerDefinition(l.type)?.kind === "content",
  );
  const postLayers = visibleLayers.filter(
    (l) => getLayerDefinition(l.type)?.kind === "post",
  );

  // Mirror v7's `{sun && <Effects/>}` gate: if any post layer references a
  // source content layer that isn't mounted yet, hold the composer off until
  // it is. Avoids a transient frame where GodRays runs against null.
  const postReady = postLayers.every((layer) => {
    const src = layer.params.sourceLayerId as ParamSchema | undefined;
    if (!src || src.type !== "select") return true;
    return objects[src.value] != null;
  });

  return (
    <div
      className={className}
      style={{ position: "absolute", inset: 0, background: config.background }}
    >
      <Leva hidden={!showEditor} collapsed={false} oneLineLabels titleBar={{ title: config.id }} />
      {showEditor && (
        <>
          <EditorTools config={config} onReplace={replaceConfig} onReset={resetConfig} />
          <LayerListPanel
            layers={config.layers}
            onReplaceLayers={replaceLayers}
            onAddLayer={addLayer}
          />
          <LevaEditor
            key={editorRev}
            config={config}
            onUpdate={updateLayerParams}
            onUpdateInteractivity={updateLayerInteractivity}
          />
        </>
      )}
      {webglOk ? (
        <WebGLErrorBoundary onError={() => setWebglOk(false)}>
          <Canvas
            dpr={dprClamp}
            gl={{ antialias: true, powerPreference: "high-performance" }}
            camera={{ position: [0, 0, 5], fov: 50 }}
            onCreated={({ gl }) => {
              // If the GPU process dies mid-session, fall back instead of
              // freezing on a black canvas.
              gl.domElement.addEventListener(
                "webglcontextlost",
                (e) => {
                  e.preventDefault();
                  setWebglOk(false);
                },
                { once: true },
              );
            }}
          >
            <PerformanceMonitor
              // Trip after a couple of consecutive declining windows so a single
              // janky frame (tab focus loss, GC pause) doesn't permanently strip
              // bloom from the scene.
              flipflops={3}
              onDecline={() => setPerfLow(true)}
              onFallback={() => setPerfLow(true)}
            />
            <color attach="background" args={[config.background]} />
            {contentLayers.map((layer) => (
              <LayerHost key={layer.id} layer={layer} ctx={ctx} />
            ))}
            {postReady && postLayers.length > 0 && (
              <EffectComposer multisampling={0}>
                {postLayers.map((layer) => (
                  <LayerHost key={layer.id} layer={layer} ctx={ctx} />
                ))}
              </EffectComposer>
            )}
          </Canvas>
        </WebGLErrorBoundary>
      ) : (
        <div aria-hidden style={{ position: "absolute", inset: 0 }}>
          {fallback}
        </div>
      )}
    </div>
  );
}

function LayerHost({ layer, ctx }: { layer: Layer; ctx: LayerContext }) {
  const def = getLayerDefinition(layer.type);
  if (!def) return null;
  const values = extractValues(layer.params);
  const Component = def.Component;
  return <Component layer={layer} values={values} ctx={ctx} />;
}
