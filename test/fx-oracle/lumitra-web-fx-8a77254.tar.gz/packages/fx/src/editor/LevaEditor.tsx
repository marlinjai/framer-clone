"use client";

/**
 * Auto-generates a leva folder per layer from that layer's param schema.
 *
 * Mapping:
 *   number -> slider, color -> color picker, select -> dropdown,
 *   bool   -> checkbox, vec2 -> XY pad.
 *
 * Writes changes back through `onUpdate(layerId, partial)` so the engine and
 * the panel share one source of truth (spec section 3).
 *
 * Phase 2 adds a second, sibling editor for per-layer `interactivity`
 * (trackMouse / momentum / spring / axes), routed through a separate
 * `onUpdateInteractivity` so the params channel stays focused on shader
 * uniforms.
 */

import { folder, useControls } from "leva";
import { useEffect, useMemo, useRef } from "react";

import type {
  InteractivitySpec,
  Layer,
  ParamSchema,
  SceneConfig,
} from "../types";

interface LevaEditorProps {
  config: SceneConfig;
  onUpdate: (layerId: string, partial: Record<string, ParamSchema["value"]>) => void;
  onUpdateInteractivity?: (
    layerId: string,
    next: InteractivitySpec | undefined,
  ) => void;
}

interface LevaSchema {
  [key: string]: unknown;
}

function paramsToLevaSchema(params: Record<string, ParamSchema>): LevaSchema {
  const out: LevaSchema = {};
  for (const [k, s] of Object.entries(params)) {
    const label = s.label ?? k;
    if (s.type === "number") {
      out[k] = { value: s.value, min: s.min, max: s.max, step: s.step ?? 0.01, label };
    } else if (s.type === "color") {
      // Always hand leva a plain color STRING. leva's color plugin throws
      // "Cannot read properties of null (reading 'alpha')" if it is ever given
      // a non-string / unparseable value, so coerce defensively here.
      out[k] = { value: typeof s.value === "string" ? s.value : "#ffffff", label };
    } else if (s.type === "select") {
      out[k] = { value: s.value, options: s.options, label };
    } else if (s.type === "bool") {
      out[k] = { value: s.value, label };
    } else if (s.type === "string") {
      // leva renders a plain text input for a string value (it only upgrades to
      // a color picker when the string looks like a color, which text content
      // never does).
      out[k] = { value: s.value, label };
    } else if (s.type === "vec2") {
      const step = s.step ?? 0.01;
      out[k] = { value: { x: s.value[0], y: s.value[1] }, step, label };
    }
  }
  return out;
}

function isXY(raw: unknown): raw is { x: number; y: number } {
  return (
    !!raw &&
    typeof raw === "object" &&
    "x" in raw &&
    "y" in raw &&
    typeof (raw as { x: unknown }).x === "number" &&
    typeof (raw as { y: unknown }).y === "number"
  );
}

function isNumberPair(raw: unknown): raw is [number, number] {
  return (
    Array.isArray(raw) &&
    raw.length === 2 &&
    typeof raw[0] === "number" &&
    typeof raw[1] === "number"
  );
}

/**
 * Coerce a value leva hands back into a JSON-plain primitive that matches the
 * param's declared type. This is load-bearing: leva can return rich objects
 * (color rgba, or a node off its own store tree) and if one of those lands in
 * the live `config` it (a) makes the autosave `JSON.stringify` throw
 * "Converting circular structure to JSON" and (b) can crash a layer on the next
 * render. Anything that doesn't match the schema falls back to the current
 * value, so config can only ever hold strings / numbers / booleans / [n, n].
 */
function coerceLevaValue(schema: ParamSchema, raw: unknown): ParamSchema["value"] {
  switch (schema.type) {
    case "number":
      return typeof raw === "number" && Number.isFinite(raw) ? raw : schema.value;
    case "bool":
      return typeof raw === "boolean" ? raw : schema.value;
    case "color":
    case "select":
    case "string":
      // A string in any CSS color notation is fine for THREE.Color.set; we only
      // need to reject non-strings (objects) so they never reach config/JSON.
      return typeof raw === "string" ? raw : schema.value;
    case "vec2":
      if (isXY(raw)) return [raw.x, raw.y];
      if (isNumberPair(raw)) return raw;
      return schema.value;
  }
}

function LayerFolder({
  layer,
  onUpdate,
  onUpdateInteractivity,
}: {
  layer: Layer;
  onUpdate: LevaEditorProps["onUpdate"];
  onUpdateInteractivity?: LevaEditorProps["onUpdateInteractivity"];
}) {
  // Build the schema once per layer.id; leva treats schema object identity as
  // the rebuild key. If a future config swaps the schema for this id, the
  // outer LevaEditor will unmount/remount the folder via React keys.
  const schema = useMemo(
    () => {
      const params = paramsToLevaSchema(layer.params);
      // Interactivity sub-folder, collapsed by default so it doesn't clutter
      // the main params for layers that don't use it.
      const interactivity = {
        Interactivity: folder(
          {
            trackMouse: {
              value: layer.interactivity?.trackMouse ?? 0,
              min: 0,
              max: 1,
              step: 0.01,
              label: "track mouse",
            },
            momentum: {
              value: layer.interactivity?.momentum ?? 0,
              min: 0,
              max: 1,
              step: 0.01,
            },
            spring: {
              value: layer.interactivity?.spring ?? 0,
              min: 0,
              max: 1,
              step: 0.01,
            },
            axes: {
              value: layer.interactivity?.axes ?? "both",
              options: ["x", "y", "both"],
            },
          },
          { collapsed: true },
        ),
      };
      return { ...params, ...interactivity };
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [layer.id],
  );
  const values = useControls(layer.name, schema) as Record<string, unknown>;

  // Skip the first emit: leva fires with its initial values on mount, which
  // already match config; no need to bounce a no-op update.
  const firstRef = useRef(true);
  useEffect(() => {
    if (firstRef.current) {
      firstRef.current = false;
      return;
    }
    const partial: Record<string, ParamSchema["value"]> = {};
    const interactivity: Partial<InteractivitySpec> = {};
    const interactivityKeys = new Set(["trackMouse", "momentum", "spring", "axes"]);
    for (const [k, raw] of Object.entries(values)) {
      if (interactivityKeys.has(k)) {
        if (k === "axes") interactivity.axes = raw as InteractivitySpec["axes"];
        else (interactivity as Record<string, number>)[k] = raw as number;
        continue;
      }
      const paramSchema = layer.params[k];
      if (!paramSchema) continue;
      partial[k] = coerceLevaValue(paramSchema, raw);
    }
    onUpdate(layer.id, partial);
    if (onUpdateInteractivity) {
      const spec: InteractivitySpec = {
        trackMouse: interactivity.trackMouse ?? 0,
        momentum: interactivity.momentum ?? 0,
        spring: interactivity.spring ?? 0,
        axes: interactivity.axes ?? "both",
      };
      // Treat the zero-vector as "no interactivity declared" so a layer that
      // never enables tracking doesn't carry an opaque spec around.
      const isZero =
        spec.trackMouse === 0 && spec.momentum === 0 && spec.spring === 0;
      onUpdateInteractivity(layer.id, isZero ? undefined : spec);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [values]);
  return null;
}

export function LevaEditor({ config, onUpdate, onUpdateInteractivity }: LevaEditorProps) {
  return (
    <>
      {config.layers.map((layer) => (
        <LayerFolder
          key={layer.id}
          layer={layer}
          onUpdate={onUpdate}
          onUpdateInteractivity={onUpdateInteractivity}
        />
      ))}
    </>
  );
}
