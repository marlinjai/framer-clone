/**
 * localStorage autosave for the live editor (Phase 1, spec section 5).
 *
 * While the leva panel is open, the working `SceneConfig` is debounced into
 * `localStorage` under a per-scene key. On reload (still in editor mode) the
 * scene rehydrates to where it was, so a tuning session survives a refresh
 * without an explicit export.
 *
 * Storage is namespaced by `id` so multiple scenes don't collide. The blob is
 * the canonical JSON (same shape `serializeScene` writes), so the autosave key
 * can be exported and imported by humans without translation.
 */

import { deserializeScene, sceneToJSON } from "../serialize";
import type { SceneConfig } from "../types";

const KEY_PREFIX = "lumitra-fx:scene:";

function storageKey(id: string): string {
  return `${KEY_PREFIX}${id}`;
}

function hasStorage(): boolean {
  if (typeof window === "undefined") return false;
  try {
    return !!window.localStorage;
  } catch {
    return false;
  }
}

/** Read a previously-saved scene by id. `null` if none, malformed, or no DOM. */
export function loadPersistedScene(id: string): SceneConfig | null {
  if (!hasStorage()) return null;
  try {
    const raw = window.localStorage.getItem(storageKey(id));
    if (!raw) return null;
    return deserializeScene(raw);
  } catch (err) {
    if (typeof console !== "undefined") {
      console.warn(`[lumitra-fx] failed to restore persisted scene "${id}":`, err);
    }
    return null;
  }
}

/** Write the canonical JSON for `config` under its id. Quota errors swallowed. */
export function persistScene(config: SceneConfig): void {
  if (!hasStorage()) return;
  try {
    window.localStorage.setItem(storageKey(config.id), sceneToJSON(config));
  } catch (err) {
    if (typeof console !== "undefined") {
      console.warn(`[lumitra-fx] could not persist scene "${config.id}":`, err);
    }
  }
}

/** Remove the saved blob; the page falls back to the in-code default on reload. */
export function clearPersistedScene(id: string): void {
  if (!hasStorage()) return;
  try {
    window.localStorage.removeItem(storageKey(id));
  } catch {
    // ignore
  }
}
