"use client";

/**
 * Layer-list panel (Phase 3, spec section 5 "The editor").
 *
 * Lists every layer in the scene in back -> front order with the four
 * operations the spec calls out:
 *
 *   - visibility toggle  (checkbox)
 *   - reorder            (up / down)
 *   - remove             (x)
 *   - add                (header dropdown picks a registered type)
 *
 * All mutations call back through `onReplaceLayers`, so the panel never
 * holds local layer state, and a Phase 1 autosave / serialize round-trip
 * picks the changes up automatically.
 *
 * Why DOM (not leva) for this list: leva's folder UI is great for params but
 * does not give us drag/move semantics, and it would mean writing every
 * mutation as a leva `button` (no batching, no compact stack of rows). A
 * minimal DOM panel is the cheapest path to the layer-list UX the spec asks
 * for; spec section 10 decision 2 explicitly says leva is plenty for MVP and
 * a custom panel is optional. We're investing the minimum to get the layer
 * list, nothing more.
 */

import { useMemo, useState } from "react";

import { getLayerDefinition } from "../registry";
import type { Layer } from "../types";
import { listAddableTypes } from "./layerOps";

interface LayerListPanelProps {
  layers: Layer[];
  onReplaceLayers: (next: Layer[]) => void;
  /**
   * Called when the panel wants to mint a brand-new layer of `type`. Lives at
   * the engine level (not here) because layer instantiation also bumps the
   * leva `editorRev` so the param panel rebuilds against the new schema.
   */
  onAddLayer: (type: string) => void;
}

const PANEL_STYLE: React.CSSProperties = {
  position: "fixed",
  top: 64,
  left: 16,
  width: 240,
  zIndex: 1001,
  padding: 8,
  background: "rgba(20, 20, 24, 0.92)",
  borderRadius: 8,
  fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
  fontSize: 11,
  color: "#e4e4eb",
  boxShadow: "0 4px 18px rgba(0,0,0,0.35)",
  display: "flex",
  flexDirection: "column",
  gap: 6,
};

const HEADER_STYLE: React.CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: 6,
  borderBottom: "1px solid #3a3a44",
  paddingBottom: 6,
};

const TITLE_STYLE: React.CSSProperties = {
  fontSize: 10,
  letterSpacing: "0.18em",
  textTransform: "uppercase",
  opacity: 0.65,
};

const ROW_STYLE: React.CSSProperties = {
  display: "grid",
  gridTemplateColumns: "auto auto 1fr auto",
  alignItems: "center",
  gap: 6,
  padding: "3px 4px",
  borderRadius: 4,
  background: "#222227",
};

const ICON_BTN_STYLE: React.CSSProperties = {
  background: "transparent",
  color: "#e4e4eb",
  border: "1px solid transparent",
  borderRadius: 3,
  padding: "1px 5px",
  cursor: "pointer",
  fontFamily: "inherit",
  fontSize: 11,
  lineHeight: 1.1,
};

const ICON_BTN_HOVER_STYLE: React.CSSProperties = {
  ...ICON_BTN_STYLE,
  borderColor: "#3a3a44",
};

const NAME_STYLE: React.CSSProperties = {
  overflow: "hidden",
  whiteSpace: "nowrap",
  textOverflow: "ellipsis",
  fontSize: 11,
};

const KIND_TAG_STYLE: React.CSSProperties = {
  fontSize: 9,
  opacity: 0.5,
  marginLeft: 6,
  letterSpacing: "0.06em",
  textTransform: "uppercase",
};

const SELECT_STYLE: React.CSSProperties = {
  flex: 1,
  background: "#2a2a30",
  color: "#e4e4eb",
  border: "1px solid #3a3a44",
  borderRadius: 4,
  padding: "3px 4px",
  fontFamily: "inherit",
  fontSize: 11,
};

const ADD_BTN_STYLE: React.CSSProperties = {
  background: "#3a3a44",
  color: "#e4e4eb",
  border: "1px solid #4a4a55",
  borderRadius: 4,
  padding: "3px 8px",
  cursor: "pointer",
  fontFamily: "inherit",
  fontSize: 11,
  letterSpacing: "0.04em",
  textTransform: "uppercase",
};

interface RowProps {
  layer: Layer;
  index: number;
  count: number;
  onToggle: (id: string) => void;
  onMove: (id: string, delta: number) => void;
  onRemove: (id: string) => void;
}

function LayerRow({ layer, index, count, onToggle, onMove, onRemove }: RowProps) {
  const def = getLayerDefinition(layer.type);
  // We list back -> front from top to bottom in the panel. So "up" in the
  // panel (visually higher row) means moving toward index 0 (further back),
  // and "down" toward count-1 (foreground). delta passed to moveLayer is the
  // raw array delta; the labels here reflect the visual direction.
  const canUp = index > 0;
  const canDown = index < count - 1;
  return (
    <div style={ROW_STYLE}>
      <input
        type="checkbox"
        checked={layer.visible}
        onChange={() => onToggle(layer.id)}
        title={layer.visible ? "Hide layer" : "Show layer"}
        style={{ accentColor: "#7c5cff", width: 12, height: 12 }}
      />
      <div style={{ display: "flex", flexDirection: "column", gap: 1 }}>
        <button
          type="button"
          style={canUp ? ICON_BTN_HOVER_STYLE : { ...ICON_BTN_STYLE, opacity: 0.3 }}
          disabled={!canUp}
          onClick={() => onMove(layer.id, -1)}
          title="Move back"
        >
          {"▲"}
        </button>
        <button
          type="button"
          style={canDown ? ICON_BTN_HOVER_STYLE : { ...ICON_BTN_STYLE, opacity: 0.3 }}
          disabled={!canDown}
          onClick={() => onMove(layer.id, +1)}
          title="Move forward"
        >
          {"▼"}
        </button>
      </div>
      <div style={NAME_STYLE} title={`${layer.name} (${layer.type})`}>
        {layer.name}
        <span style={KIND_TAG_STYLE}>{def?.kind ?? "?"}</span>
      </div>
      <button
        type="button"
        style={ICON_BTN_HOVER_STYLE}
        onClick={() => onRemove(layer.id)}
        title="Remove layer"
      >
        {"✕"}
      </button>
    </div>
  );
}

export function LayerListPanel({ layers, onReplaceLayers, onAddLayer }: LayerListPanelProps) {
  const addable = useMemo(() => listAddableTypes(), []);
  const [pickType, setPickType] = useState<string>(addable[0]?.type ?? "");

  return (
    <div style={PANEL_STYLE}>
      <div style={HEADER_STYLE}>
        <span style={TITLE_STYLE}>Layers</span>
        <span style={{ ...TITLE_STYLE, opacity: 0.45 }}>{layers.length}</span>
      </div>

      {layers.length === 0 && (
        <div style={{ opacity: 0.55, fontSize: 11, padding: "4px 0" }}>
          No layers. Add one below.
        </div>
      )}

      {layers.map((layer, i) => (
        <LayerRow
          key={layer.id}
          layer={layer}
          index={i}
          count={layers.length}
          onToggle={(id) =>
            onReplaceLayers(
              layers.map((l) => (l.id === id ? { ...l, visible: !l.visible } : l)),
            )
          }
          onMove={(id, delta) => {
            const idx = layers.findIndex((l) => l.id === id);
            const target = idx + delta;
            if (idx < 0 || target < 0 || target >= layers.length) return;
            const next = layers.slice();
            const [item] = next.splice(idx, 1);
            next.splice(target, 0, item);
            onReplaceLayers(next);
          }}
          onRemove={(id) => onReplaceLayers(layers.filter((l) => l.id !== id))}
        />
      ))}

      <div style={{ display: "flex", gap: 6, paddingTop: 4, borderTop: "1px solid #3a3a44" }}>
        <select
          value={pickType}
          onChange={(e) => setPickType(e.target.value)}
          style={SELECT_STYLE}
          title="Pick a layer type to add"
        >
          {addable.map((t) => (
            <option key={t.type} value={t.type}>
              {t.label} ({t.kind})
            </option>
          ))}
        </select>
        <button
          type="button"
          style={ADD_BTN_STYLE}
          onClick={() => pickType && onAddLayer(pickType)}
          title="Add a new layer of the selected type"
        >
          Add
        </button>
      </div>
    </div>
  );
}
