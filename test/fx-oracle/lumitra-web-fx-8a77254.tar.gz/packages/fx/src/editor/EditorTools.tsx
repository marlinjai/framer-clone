"use client";

/**
 * Editor toolbox (Phase 1, spec section 5 "Persistence").
 *
 * Four buttons that operate on the live `SceneConfig`:
 *
 *   - Export     download `<id>.json` and copy the same blob to the clipboard
 *   - Import     accept a `.json` file or a pasted blob, deserialize, replace
 *   - Embed      copy a `<LumitraScene config={...} />` snippet to the clipboard
 *   - Reset      wipe the autosave and reload the original (in-code) config
 *
 * The panel is intentionally vanilla DOM (no leva folder, no Tailwind) so the
 * engine stays portable, and so future projects that drop `@lumitra-web/fx` into a
 * non-Tailwind stack don't inherit our app's styling.
 */

import { useCallback, useRef, useState } from "react";

import { deserializeScene, sceneToJSON, serializeScene } from "../serialize";
import { PRESETS, findPreset } from "../presets";
import type { SceneConfig } from "../types";

interface EditorToolsProps {
  config: SceneConfig;
  /** Replace the entire scene (used by Import / Reset). */
  onReplace: (next: SceneConfig) => void;
  /** Reset to the in-code default (clears autosave, re-applies the seed). */
  onReset: () => void;
}

const PANEL_STYLE: React.CSSProperties = {
  position: "fixed",
  top: 16,
  left: 16,
  zIndex: 1001,
  display: "flex",
  gap: 6,
  padding: 8,
  background: "rgba(20, 20, 24, 0.9)",
  borderRadius: 8,
  fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace",
  fontSize: 11,
  color: "#e4e4eb",
  boxShadow: "0 4px 18px rgba(0,0,0,0.35)",
};

const BTN_STYLE: React.CSSProperties = {
  background: "#2a2a30",
  color: "#e4e4eb",
  border: "1px solid #3a3a44",
  borderRadius: 4,
  padding: "4px 9px",
  cursor: "pointer",
  fontFamily: "inherit",
  fontSize: 11,
  letterSpacing: "0.04em",
  textTransform: "uppercase",
};

const STATUS_STYLE: React.CSSProperties = {
  alignSelf: "center",
  marginLeft: 4,
  opacity: 0.7,
};

function downloadJSON(name: string, json: string): void {
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${name}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

function buildEmbedSnippet(config: SceneConfig): string {
  // Inline the serialized scene so the snippet is self-contained. Recipients
  // can also factor it into a `*.json` import; both render identically.
  const json = JSON.stringify(serializeScene(config), null, 2);
  return [
    `import { LumitraScene } from "@lumitra-web/fx";`,
    ``,
    `const scene = ${json};`,
    ``,
    `<LumitraScene config={scene} />`,
  ].join("\n");
}

export function EditorTools({ config, onReplace, onReset }: EditorToolsProps) {
  const [status, setStatus] = useState<string>("");
  const fileRef = useRef<HTMLInputElement | null>(null);

  const flash = useCallback((msg: string) => {
    setStatus(msg);
    window.setTimeout(() => setStatus(""), 1800);
  }, []);

  const doExport = useCallback(async () => {
    const json = sceneToJSON(config);
    downloadJSON(config.id, json);
    const copied = await copyToClipboard(json);
    flash(copied ? "Exported (copied)" : "Exported");
  }, [config, flash]);

  const doImport = useCallback(() => {
    fileRef.current?.click();
  }, []);

  const onFile = useCallback(
    async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      e.target.value = ""; // allow re-import of the same filename
      if (!file) return;
      try {
        const text = await file.text();
        const next = deserializeScene(text);
        onReplace(next);
        flash("Imported");
      } catch (err) {
        flash(err instanceof Error ? err.message : "Import failed");
      }
    },
    [onReplace, flash],
  );

  const doPaste = useCallback(async () => {
    try {
      const text = await navigator.clipboard.readText();
      const next = deserializeScene(text);
      onReplace(next);
      flash("Pasted");
    } catch (err) {
      flash(err instanceof Error ? err.message : "Paste failed");
    }
  }, [onReplace, flash]);

  const doEmbed = useCallback(async () => {
    const snippet = buildEmbedSnippet(config);
    const copied = await copyToClipboard(snippet);
    flash(copied ? "Embed copied" : "Embed ready");
  }, [config, flash]);

  const doReset = useCallback(() => {
    onReset();
    flash("Reset to default");
  }, [onReset, flash]);

  const doLoadPreset = useCallback(
    (id: string) => {
      const p = findPreset(id);
      if (!p) {
        flash("Unknown preset");
        return;
      }
      try {
        onReplace(p.load());
        flash(`Loaded ${p.label}`);
      } catch (err) {
        flash(err instanceof Error ? err.message : "Preset failed");
      }
    },
    [onReplace, flash],
  );

  return (
    <div style={PANEL_STYLE}>
      <button type="button" style={BTN_STYLE} onClick={doExport} title="Download JSON + copy to clipboard">
        Export
      </button>
      <button type="button" style={BTN_STYLE} onClick={doImport} title="Load a JSON scene from disk">
        Import
      </button>
      <button type="button" style={BTN_STYLE} onClick={doPaste} title="Read JSON from clipboard">
        Paste
      </button>
      <button type="button" style={BTN_STYLE} onClick={doEmbed} title="Copy <LumitraScene config=...> snippet">
        Embed
      </button>
      <button type="button" style={BTN_STYLE} onClick={doReset} title="Wipe autosave, restore in-code default">
        Reset
      </button>
      <select
        defaultValue=""
        onChange={(e) => {
          const val = e.target.value;
          // Reset to the placeholder so the same preset can be loaded twice.
          e.target.value = "";
          if (val) doLoadPreset(val);
        }}
        title="Load a built-in preset scene"
        style={{
          background: "#2a2a30",
          color: "#e4e4eb",
          border: "1px solid #3a3a44",
          borderRadius: 4,
          padding: "3px 6px",
          fontFamily: "inherit",
          fontSize: 11,
          letterSpacing: "0.04em",
          textTransform: "uppercase",
        }}
      >
        <option value="">Preset…</option>
        {PRESETS.map((p) => (
          <option key={p.id} value={p.id}>
            {p.label}
          </option>
        ))}
      </select>
      <span style={STATUS_STYLE}>{status}</span>
      <input
        ref={fileRef}
        type="file"
        accept="application/json,.json"
        style={{ display: "none" }}
        onChange={onFile}
      />
    </div>
  );
}
