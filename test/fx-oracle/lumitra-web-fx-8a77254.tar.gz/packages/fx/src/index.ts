/**
 * Public surface of the Lumitra FX engine (`@lumitra-web/fx`).
 *
 * Importing this module registers the built-in layers (side effect in
 * `./builtins`). New scenes should depend on this entry point so the
 * registry is populated before any LumitraScene mounts.
 *
 * Per spec section 6 (Package and API) the package exposes three surfaces:
 *
 *   - <LumitraScene config interactive editor /> for React consumers
 *   - createScene(config) for vanilla / non-React hosts (see ./createScene)
 *   - registerNode(definition) (primary; registerLayer is a kept alias) to
 *     extend the layer registry
 *
 * The core types (`SceneConfig`, `Layer`, `ParamSchema`, ...) are re-exported
 * so every consumer authors against the same shape the editor reads/writes.
 *
 * U1 adds `sceneConfigFromUnified`: the boundary adapter that reads a unified
 * `@marlinjai/studio-scene-core` scene blob and converts it down into a
 * `SceneConfig` the render path already understands.
 */

import "./builtins";

export { LumitraScene } from "./LumitraScene";
export { createScene, type LumitraSceneHandle } from "./createScene";
export {
  registerNode,
  registerLayer,
  getLayerDefinition,
  listLayerDefinitions,
} from "./registry";
export { sceneConfigFromUnified } from "./unified";
export { resolveAnimatedNumber } from "./animation";
export {
  deserializeScene,
  sceneToJSON,
  serializeScene,
  type SerializedScene,
} from "./serialize";
export {
  clearPersistedScene,
  loadPersistedScene,
  persistScene,
} from "./editor/persistence";
export { PRESETS, findPreset, type PresetMeta } from "./presets";
export {
  DEFAULT_INTERACTIVITY,
  readInteractivity,
  useInteractivity,
  useInteractivitySpec,
  type InteractivityTarget,
} from "./interactivity";
export { SCENE_SCHEMA_VERSION } from "./types";
export type {
  AnimateSpec,
  BlendMode,
  InteractivitySpec,
  Layer,
  LayerComponentProps,
  LayerContext,
  LayerDefinition,
  LayerKind,
  ParamSchema,
  ParamValueOf,
  ParamValues,
  ParamsSchema,
  SceneConfig,
} from "./types";
